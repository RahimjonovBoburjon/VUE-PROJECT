<template>
  <div class="container" id="app" v-cloak>
    <div class="card">
      <h1>Front-End kurs rejasi</h1>

      <div class="steps">
        <div class="steps-content">
          {{ steps[activeIndex].text }}
        </div>
        <ul class="steps-list">
          <li
            v-for="(item, idx) in steps"
            :key="item.title"
            @click="setActive(idx)"
            :class="{
              'steps-item' : true,
              active: idx === activeIndex,
              done: activeIndex > idx,
            }"
          >
            <span>{{ idx + 1 }}</span
            >{{ item.title }}
          </li>
        </ul>
        <div>
          <div v-if="isActive">
            <button class="btn" @click="prev" :disabled="activeIndex === 0">
              Orqaga
            </button>
            <button class="btn primary" @click="next">
              {{ activeIndex < steps.length - 1 ? "Oldinga" : "Tugatish" }}
            </button>
          </div>
          <button v-else class="btn" @click="reset">Qaytadan boshlash</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      activeIndex: 1,
      isActive: true,
      steps: [
        {
          title: "HTML",
          text: "Web ilovaning strukturasini tuzish uchun xizmat qiladi",
        },
        {
          title: "CSS",
          text: "Web ilovamizning tayyor bo'lgan strukturasiga bezak berish uchun ishlatamiz",
        },
        {
          title: "Sass",
          text: "Css da style berishning osonroq qulayroq va bir qancha qo'shimcha imkoniyatlar yaratib beruvchi css tili",
        },
        {
          title: "JavaScript",
          text: "Web ilovaning dinamik ishlashi uchun va biror elementlarni harakatlantirish uchun xizmat qiluvchi dasturlash tili ",
        },
        {
          title: "VueJS",
          text: "JavaScript dasturlash tilining frameworki hisoblanib web ilovani oson va optimal, reaktiv progressiv qilib ishashi uchun xizmat qiladi",
        },
      ],
    };
  },
  methods: {
    next() {
      if (this.activeIndex < this.steps.length - 1) {
        this.activeIndex++;
      } else {
        this.isActive = false;
      }
    },
    prev() {
      this.activeIndex--;
    },
    reset() {
      this.activeIndex = 0;
      this.isActive = true;
    },
    setActive(index) {
      this.activeIndex = index;
      this.isActive = true;
    },
  },
};
</script>

<style>
</style>  