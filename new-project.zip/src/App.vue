<template>
  <div class="container" id="app">
    <div class="card">
      <h1 class="h1">Numbers list</h1>
      <div class="form-control">
        <input type="text" class="input" v-model="inputText" />
        <small :style="{ color: inputText < 0 ? 'red' : 'green' }">{{
          title
        }}</small>
      </div>
      <p v-if="inputText.length > 0">
        {{ arrayText }}
      </p>
      <div class="btns">
        <button class="btn" @click="toggle">TOGGLE LIST</button>
        <button class="btn primary" @click="push">PUSH NUMBER</button>
        <button class="btn danger" @click="remove">POP NUMBER</button>
        <button class="btn warning" @click="rever">REVERSE LIST</button>
      </div>
      <div class="new-div">
        <ul class="list" v-if="!isNumber">
          <li v-for="item in numberarray" :key="item" class="list-item">
            {{ item }}
          </li>
        </ul>
        <p v-else-if="numberarray.length == 0">List is empty</p>
        <p v-else>List is not empty, but hidden</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      have: true,
      isNumber: false,
      numberarray: [],
      inputText: "",
      title: "Enter the number to check",
    };
  },
  methods: {
    push() {
      this.numberarray.push(this.numberarray.length + 1);
    },
    remove() {
      this.numberarray.pop(this.numberarray.length - 1);
    },
    rever() {
      this.numberarray.reverse();
    },
    toggle() {
      this.isNumber = !this.isNumber;
    },
  },
  computed: {
    arrayText() {
      if (this.numberarray.includes(Number(this.inputText))) {
        return "The array contains this number";
      } else {
        return "The number does not exist in the array";
      }
    },
  },
  watch: {
    inputText(value) {
      if (value < 0) {
        this.title = "There are no negative numbers in this list";
      } else {
        this.title = "Enter the number to check";
      }
    },
  },
};
</script>

<style></style>