<template>
    <div class="container">
        <app-alert v-if="alert" :alert="alert" @close="alert = null"></app-alert>
        <div class="card">
            <h2>Ismingizni kriting</h2>
            <form @submit.prevent="create()">
                <div class="form-control">
                    <input type="text" v-model="userName" />
                </div>
                <button class="btn">Jo'natish</button>
            </form>
        </div>
        <app-loader v-if="isLoding"></app-loader>
        <div class="users" v-if="users.length > 0">
            <app-users-list v-for="user in users" :key="user.id" :user="user" @delete="deleteItem"></app-users-list>
        </div>
        <div class="card center" v-else-if="users.length === 0 && !isLoding">
            <p>There are any info</p>
            <button class="btn" @click="getUsers()">Get info</button>
        </div>
    </div>
</template>
  
<script>
import AppUsersList from "./components/AppUsers.vue";
import AppLoader from "./components/AppLoader.vue";
import AppAlert from "./components/AppAlert.vue";
import axios from "axios";
export default {
    data() {
        return {
            API: "https://tes-user-19a9a-default-rtdb.firebaseio.com/",
            userName: "",
            users: [],
            isLoding: false,
            alert: null,
        };
    },
    methods: {
        async create() {
            try {
                this.isLoding = true;
                const resp = await fetch(this.API + "users.json", {
                    method: "POST",
                    headers: {
                        "Content-type": "Application/json",
                    },
                    body: JSON.stringify({
                        userName: this.userName,
                    }),
                });
                const data = await resp.json();
                this.users.push({
                    id: data.name,
                    userName: this.userName,
                });
                this.alert = {
                    title: "Added new user",
                    text: "User name: " + this.userName,
                    type: "primary",
                };
                this.getUsers();
                this.userName = "";
            } catch (error) {
                console.log(error);
            } finally {
                this.isLoding = false;
            };
        },
        async getUsers() {
            try {
                this.isLoding = true;
                const { data } = await axios.get(this.API + "users.json");
                if (!data) {
                    throw new Error("There is no information");
                }
                this.users = Object.keys(data).map((key) => {
                    return {
                        id: key,
                        ...data[key],
                        // userName: data[key].userName,
                    };
                });
            } catch (error) {
                console.log(error);
            } finally {
                this.isLoding = false;
            };
        },
        async deleteItem(id) {
            try {
                this.isLoding = true;
                const deletedUser = this.users.find((user) => user.id === id).userName;
                await axios.delete(this.API + `users/${id}.json`);
                this.users = this.users.filter((elem) => elem.id !== id);
                this.alert = {
                    title: "User deleted",
                    text: "User name: " + deletedUser,
                    type: "danger",
                };
            } catch (error) {
                console.log(error);
            } finally {
                this.isLoding = false;
            };
        },
    },

    components: {
        AppUsersList,
        AppLoader,
        AppAlert,
    },
};
</script>
  
<style>

</style>