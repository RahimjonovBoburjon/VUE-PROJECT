<template>
    <div class="alert" :class="alert.type">
        <div class="alert-title">{{ alert.title }}</div>
        <p>{{ alert.text }}</p>
        <button :class="alert.type" class="btn" @click="$emit('close')">Close</button>
    </div>
</template>

<script>
export default {
    props: ["alert"],
    emits: ["close"],
}
</script>

<style>

</style>