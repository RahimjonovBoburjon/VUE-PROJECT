<template>
    <div class="card flex">
        <h3>{{ user.userName }}</h3>
        <button class="btn danger" @click="$emit('delete', user.id)">Delete</button>
    </div>
</template>
  
<script>
export default {
    props: {
        user: {
            type: Object,
            required: true,
        },
    },
};
</script>
  
<style>
.flex {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
</style>